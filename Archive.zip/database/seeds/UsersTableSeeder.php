<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('users')->insert([
        //     'name' => 'Syahrin Seth',
        //     'email' => 'syah@syahrinseth.com',
        //     'user_type' => 'admin',
        //     'password' => bcrypt('Syahrin221166'),
        // ]);
        DB::table('master_categories')->insert([
            [
                'category' => 'php',
                'description' => '',
                'parent_category' => Null
            ],
            [
                'category' => 'photography',
                'description' => '',
                'parent_category' => Null
            ],
        ]);
    }
}

<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){
        $('#blog').attr('class', 'active');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
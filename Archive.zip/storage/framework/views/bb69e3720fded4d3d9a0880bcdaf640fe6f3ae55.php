<?php if(count($errors)): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger landing-alert alert-dismissible">
            <div class="container text-center">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="position:unset;">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3><?php echo e($error); ?></h3>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

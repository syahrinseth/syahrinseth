<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <?php echo $__env->make('Layouts.message-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('Layouts.validate-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Blog Posts</h4>
                 <a href="<?php echo e(route('create.adminblog')); ?>" class="btn btn-simple btn-sm"><i class="fas fa-plus"></i> New Post</a>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table" id="posts_list">
                    <thead class=" text-primary">
                      <tr><th>
                        Title(s)
                      </th>
                      <th>
                        Category(s)
                      </th>
                      <th>
                        Author(s)
                      </th>
                      <th>
                        Updated At
                      </th>
                      <th class="">
                        Created At
                      </th>
                      <th>
                        Total View(s)
                      </th>
                      <th>
                        Status
                      </th>
                      <th>
                        Action
                      </th>
                    </tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $MasterBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MasterBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>
                          <?php echo e(ucfirst($MasterBlog->title)); ?>

                        </td>
                        <td>
                          <?php echo e($MasterBlog->title); ?>

                        </td>
                        <td>
                          <?php echo e($MasterBlog->author); ?>

                        </td>
                        <td class="">
                          <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($MasterBlog->updated_at))->formatLocalized('%d %B %Y')); ?>

                        </td>
                        <td>
                            <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($MasterBlog->created_at))->formatLocalized('%d %B %Y')); ?>

                        </td>
                        <td>
                            <?php echo e($MasterBlog->total_views); ?>

                        </td>
                        <td>
                            <?php if($MasterBlog->publish == 1): ?>
                                Published
                            <?php else: ?>
                                Unpublished
                            <?php endif; ?>
                        </td>
                        <td>
                            <a class="nav-link btn btn-simple btn-sm nc-icon nc-settings-gear-65" href="http://example.com" id="navbarDropdownMenuLinkCustom" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLinkCustom">
                                <a class="dropdown-item" href="<?php echo e(route('show.adminblog', [ 'slug' => $MasterBlog->slug ])); ?>" target="_blank">View</a>
                                <a class="dropdown-item" href="<?php echo e(route('edit.adminblog', [ 'id' => $MasterBlog->id ])); ?>">Edit</a>
                                <a class="dropdown-item" href="<?php echo e(route('delete.adminblog', ['id' => $MasterBlog->id])); ?>">Delete</a>
                            </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                    <div class="pull-right">
                        <?php echo $MasterBlogs->links(); ?>

                    </div>
                </div>
              </div>
            </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){
        $('#blog').attr('class', 'active');

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
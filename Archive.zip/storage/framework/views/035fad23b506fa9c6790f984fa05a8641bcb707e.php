<footer class="footer-demo section-dark">
        <div class="container">
            <nav class="pull-left">
                <ul>
                    <li>
                        <a href="<?php echo e(route('/')); ?>#services">
                            Services
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('index.portfolio')); ?>">
                            Portfolio
                        </a>
                    </li>
                    <!-- <li>
                        <a href="#">
                           Blog
                        </a>
                    </li> -->
                    <li>
                    <?php if(Auth::user()): ?>

                        <a href="<?php echo e(route('dashboard')); ?>">
                           Dashboard
                        </a>

                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">
                           Login
                        </a>
                    <?php endif; ?>
                    </li>
                    <!-- <li>
                        <a href="#">
                            Licenses
                        </a>
                    </li> -->
                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; 2018, made with <i class="fa fa-heart heart"></i> by Syahrin Seth v1.0.0
            </div>
        </div>
    </footer>

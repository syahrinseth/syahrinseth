<?php $__env->startSection('title', 'Delete Post'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('destroy.adminblog', ['id' => $masterBlog->id])); ?>" method="post">
                    <h5>Are you sure to delete <?php echo e(ucfirst($masterBlog->title)); ?>?<h5>
                    <hr>
                    <a href="<?php echo e(route('index.adminblog')); ?>" class="btn btn-default btn-sm">Cancel</a>
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    <?php echo e(csrf_field()); ?>

                </form>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){
        $('#blog').attr('class', 'active');

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
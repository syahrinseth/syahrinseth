<?php $__env->startSection('title', ucfirst($MasterBlog->title)); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper">
    <div class="main">
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo e(ucfirst($MasterBlog->title)); ?></h1>
                        <h6>by <strong><?php echo e($MasterBlog->author); ?></strong></h6>
                        <p><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($MasterBlog->created_at))->formatLocalized('%A %d %B %Y')); ?></p>
                        <?php if(Auth::user()): ?>
                            <?php if(Auth::user()->user_type == "admin"): ?>
                                <a class="dropdown-item" href="<?php echo e(route('edit.adminblog', [ 'id' => $MasterBlog->id ])); ?>">Edit</a>
                            <?php endif; ?>
                        <?php endif; ?>
                        <hr>
                        <div class="panel">
                            <div class="panel-body">
                                <?php if($MasterBlog->cover_img != null): ?>
                                    <img class="panel-img-top cover-img" src="<?php echo e(str_replace('public', 'storage', $MasterBlog->cover_img)); ?>" alt="Card image cap" width="400px">
                                <?php endif; ?>
                                <?php if($MasterBlog->body != null): ?>
                                    <p><?php echo $MasterBlog->body; ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <h5>Comment:</h5>
                                        <form action="<?php echo e(route('create_blog_comment.blog', [ 'id' => $MasterBlog->id ])); ?>" method="post">
                                            <div class="form-group">
                                                <label for="name-<?php echo e($MasterBlog->id); ?>">Name</label>
                                                <input type="text" name="name" id="name-<?php echo e($MasterBlog->id); ?>" class="form-control" placeholder="Comment as...">
                                            </div>
                                            <div class="form-group">
                                                <label for="comment-<?php echo e($MasterBlog->id); ?>">Comment</label>
                                                <textarea name="body" id="body-<?php echo e($MasterBlog->id); ?>" cols="30" rows="10" class="form-control" placeholder="Comment here..."></textarea>
                                            </div>
                                            <br>
                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="btn btn-success btn-sm pull-right">Post</button>
                                        </form>
                                        <br>
                                        <hr>
                                    </div>
                                    <div class="col-sm-12">
                                        <?php if(count($blogComments) > 0): ?>

                                                <h5>Comments:</h5>
                                                <?php $__currentLoopData = $blogComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="panel">
                                                    <div class="panel-body">
                                                        <label for="">Name:</label>
                                                        <br>
                                                        <input type="text" class="form-control" value="<?php echo e($blogComment->name); ?>" readonly>

                                                        <br>
                                                        <label for="">Comment:</label>
                                                        <br>
                                                        <textarea name="" id="" cols="30" rows="3" class="form-control"  readonly><?php echo e($blogComment->body); ?></textarea>
                                                        <br>
                                                        <small class="pull-right"><?php echo e(App\BlogComment::whenCreated($blogComment->created_at)); ?></small>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <h3>You May Also Like:</h3>
                        <div class="row">
                            <?php $__currentLoopData = $postsRand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                            <a href="<?php echo e(route('show.blog', ['slug'=>$post->slug])); ?>" title="<?php echo e(ucfirst($post->title)); ?>">
                                <div class="panel" style="width: 20rem;">
                                    <?php if($post->cover_img != null): ?>
                                        <img class="panel-img-top" src="<?php echo e(str_replace('public', 'storage', $post->cover_img)); ?>" alt="Card image cap" width="100%">
                                    <?php endif; ?>
                                    <div class="panel-body">
                                        <p class="panel-text"><?php echo e(ucfirst($post->title)); ?></p>
                                    </div>
                                    <div class="panel-footer">
                                        <?php
                                            // strip tags to avoid breaking any html
                                            $body = $post->body;
                                            if (strlen($body) > 100) {

                                                // truncate string
                                                $stringCut = substr($body, 0, 100);
                                                $endPoint = strrpos($stringCut, ' ');

                                                //if the string doesn't contain any space then it will cut without word basis.
                                                $body = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
                                                $route = route('show.blog', [ 'slug' => $post->slug ]);
                                                $body .= '... <a href="'.$route.'">Read More</a>';
                                            }
                                        ?>
                                        <?php echo $body; ?>

                                        <p></p>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- <div class="col-md-2">

                    </div> -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){
        $('a[id="blog-nav"]').attr('class', 'active');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
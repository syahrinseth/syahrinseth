<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-10">
            <h1><?php echo e(ucfirst($MasterBlog->title)); ?></h1>
            <h6>by <strong><?php echo e($MasterBlog->author); ?></strong></h6>
            <p><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($MasterBlog->created_at))->formatLocalized('%A %d %B %Y')); ?></p>
            <?php if(Auth::user()->user_type == "admin"): ?>
                <a class="dropdown-item" href="<?php echo e(route('edit.adminblog', [ 'id' => $MasterBlog->id ])); ?>">Edit</a>
            <?php endif; ?>
            <hr>
            <p><?php echo $MasterBlog->body; ?></p>
            <hr>
            <h3>You May Also Like:</h3>
            <div class="row">
                <?php $__currentLoopData = $postsRand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="panel">
                        <div class="panel-title text-center">
                            <?php echo e(ucfirst($post->title)); ?>

                        </div>
                        <div class="panel-body">
                            <?php echo str_limit($post->body, $limit = 20, $end = '...'); ?>

                            <br>
                            <a class="btn btn-primary btn-sm pull-right" href="<?php echo e(route('edit.adminblog', [ 'id' => $MasterBlog->id ])); ?>">Read More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-2">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){
        $('#blog').attr('class', 'active');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
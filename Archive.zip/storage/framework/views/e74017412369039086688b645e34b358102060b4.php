<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main">
        <div class="section">
            <div class="container">
                <?php if(count($MasterBlogs) > 0): ?>
                        <div class="row">
                            <div class="col-md-3" style="float:right;">
                                <div class="panel">
                                    <div class="panel-body">
                                        <h6>Categories</h6>
                                        <hr>
                                        <form action="" id="form-categories" method="get">
                                        </form>
                                        <div class="form-group">
                                            <select name="categories" class="form-control" id="categories">
                                                <option value="">All</option>
                                                <?php if(count($categories) > 0): ?>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" <?php echo e($category['id'] == $item->id ? 'selected' : ''); ?>><?php echo e(ucfirst($item->category)); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php $__currentLoopData = $MasterBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MasterBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-9">
                                <h1><a href="<?php echo e(route('show.blog', [ 'slug' => $MasterBlog->slug ])); ?>"><?php echo e(ucfirst($MasterBlog->title)); ?></a></h1>
                                <h6>by <strong><?php echo e($MasterBlog->author); ?></strong></h6>
                                <p><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($MasterBlog->created_at))->formatLocalized('%A %d %B %Y')); ?></p>
                                <?php if(Auth::user() != null): ?>
                                    <?php if(Auth::user()->user_type == "admin"): ?>
                                        <a class="dropdown-item" href="<?php echo e(route('edit.adminblog', [ 'id' => $MasterBlog->id ])); ?>">Edit</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <hr>
                                <div class="panel">
                                    <div class="panel-body">
                                        <?php if($MasterBlog->cover_img != null): ?>
                                            <img class="panel-img-top cover-img" src="<?php echo e(str_replace('public', 'storage', $MasterBlog->cover_img)); ?>" alt="Card image cap" width="400px">
                                        <?php endif; ?>
                                        <?php
                                            // strip tags to avoid breaking any html
                                            $body = $MasterBlog->body;
                                            if (strlen($body) > 1000) {

                                                // truncate string
                                                $stringCut = substr($body, 0, 1000);
                                                $endPoint = strrpos($stringCut, ' ');

                                                //if the string doesn't contain any space then it will cut without word basis.
                                                $body = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
                                                $route = route('show.blog', [ 'slug' => $MasterBlog->slug ]);
                                                $body .= '... <a href="'.$route.'">Read More</a>';
                                            }
                                        ?>
                                        <p><?php echo $body; ?></p>
                                    </div>

                                </div>
                                <hr>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                        <div class="row">
                            <div class="col-md-10">
                                <div style="float:right">
                                    <?php echo $MasterBlogs->links(); ?>

                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                    <div class="row" style="height:500px;">
                            <div class="col-md-3" style="float:right;">
                                <div class="panel">
                                    <div class="panel-body">
                                        <h6>Categories</h6>
                                        <hr>
                                        <form action="" id="form-categories" method="get">
                                        </form>
                                        <div class="form-group">
                                            <select name="categories" class="form-control" id="categories">
                                                <option value="">select</option>
                                                <?php if(count($categories) > 0): ?>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" <?php echo e($category['id'] == $item->id ? 'selected' : ''); ?>><?php echo e(ucfirst($item->category)); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <h1>Sorry, what you looking for are not here...</h1>
                            </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){
        $('a[id="blog-nav"]').attr('class', 'active');

        var e = document.getElementById("categories");
        e.addEventListener("change", function(){
            var value = e.options[e.selectedIndex].value;
            var form = document.getElementById('form-categories');
            if(value.length > 0){
                form.setAttribute("action", '/blog/category/'+value);
            }else{
                form.setAttribute("action", '/blog');
            }
            $('#form-categories').submit();

        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
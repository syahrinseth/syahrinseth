<footer class="footer-demo section-dark">
        <div class="container">
            <nav class="pull-left">
                <ul>

                    <li>
                        <a href="#">
                            Portfolio
                        </a>
                    </li>
                    <li>
                        <a href="#">
                           Blog
                        </a>
                    </li>
                    <li>
                    <?php if(Auth::user()): ?>
                        <?php if(Auth::user()->user_type == 'admin'): ?>
                        <a href="<?php echo e(route('dashboard')); ?>">
                           Admin Page
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">
                           Login
                        </a>
                    <?php endif; ?>
                    </li>
                    <li>
                        <a href="#">
                            Licenses
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; 2018, made with <i class="fa fa-heart heart"></i> by Syahrin Seth
            </div>
        </div>
    </footer>

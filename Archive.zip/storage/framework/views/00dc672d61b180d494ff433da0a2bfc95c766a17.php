<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main">
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-10">
                        <h1><?php echo e(ucfirst($MasterBlog->title)); ?></h1>
                        <h6>by <strong><?php echo e($MasterBlog->author); ?></strong></h6>
                        <p><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($MasterBlog->created_at))->formatLocalized('%A %d %B %Y')); ?></p>
                        <?php if(Auth::user()->user_type == "admin"): ?>
                            <a class="dropdown-item" href="<?php echo e(route('edit.adminblog', [ 'id' => $MasterBlog->id ])); ?>">Edit</a>
                        <?php endif; ?>
                        <hr>
                        <div class="panel">
                            <div class="panel-body">
                                <img class="panel-img-top cover-img" src="/storage/blog/<?php echo e($MasterBlog->id); ?>/<?php echo e($MasterBlog->cover_img); ?>" alt="Card image cap" width="400px">
                                <p><?php echo $MasterBlog->body; ?></p>
                            </div>
                        </div>
                        <hr>
                        <h3>You May Also Like:</h3>
                        <div class="row">
                            <?php $__currentLoopData = $postsRand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                            <a href="<?php echo e(route('show.blog', ['slug'=>$post->slug])); ?>" title="<?php echo e(ucfirst($post->title)); ?>">
                                <div class="panel" style="width: 20rem;">
                                    <img class="panel-img-top" src="/storage/blog/<?php echo e($post->id); ?>/<?php echo e($post->cover_img); ?>" alt="Card image cap" width="100%">
                                    <div class="panel-body">
                                        <p class="panel-text"><?php echo e(ucfirst($post->title)); ?></p>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-2">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-javascript'); ?>
<script>
    jQuery(document).ready(function(){

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
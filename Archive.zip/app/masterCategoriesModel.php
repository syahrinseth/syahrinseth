<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class masterCategoriesModel extends Model
{
    protected $table = 'master_categories';
    protected $primary = 'id';
}
